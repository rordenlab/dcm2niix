#ifndef UNTGZ_H__
#define UNTGZ_H__

//extern const char const *one_hit_wonder;

int untargz( char * fname, char * outdir);

#endif